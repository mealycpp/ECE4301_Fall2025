# ECE 4301 Quiz 2 # 

### How to run the code ###

First, install the system dependency called `kcapi-tools` (`sudo apt install kcapi-tools`).

The entire project can be run by executing either the `run-experiments.sh` script or the `run-demo.sh` script. 

* `run-experiments.sh` will run the tests that were used to acquire the data for the report PDF file. This will run each implementation (hardware-accelerated and software-only) and the kernel engine with four different input buffers (1 KiB, 8 KiB, 64 KiB, and 1 MiB) and print the results.
* `run-demo.sh` will run a script that will get images from the Pi's camera and compute their hashes.

If you would rather compile and run the project yourself, you can build an executable with either of the following commands: 

    cargo build --features hw-accel     # Enables hardware acceleration

    cargo build     # Software-only implementation

To run the executable, enter the target/debug folder (`cd target/debug`) and run the `rehash` executable. Below is the executable's help message.

```
Usage: rehash [OPTIONS] <FILE>

Arguments:
  <FILE>  Path to the input file

Options:
  -a, --algorithm <ALGORITHM>    Hash algorithm to use: sha1 or sha256 [default: sha256] [possible values: sha1, sha256]
  -i, --iterations <ITERATIONS>  Number of times to hash the file (must be >= 1) [default: 1]
      --print-digest             Also print the final digest (hex) from the last iteration
  -h, --help                     Print help
```

Example usage:

    ./rehash 64K.bin --iterations 10 --algorithm sha1 --print-digest

### Results ###

Shown below is the raw output from the experiments of `run-experiments.sh`:

```
Algorithm: Sha1
File: 1K.bin
Size: 1024 bytes
Iterations: 10
HW accel: enabled

Elapsed: 0.000128 s | Throughput: 76.42 MiB/s
Final digest (last iteration): a29f7a414d57acb2f6f70dd12906fe89743071be


Algorithm: Sha1
File: 1K.bin
Size: 1024 bytes
Iterations: 10
HW accel: disabled

Elapsed: 0.000823 s | Throughput: 11.87 MiB/s
Final digest (last iteration): a29f7a414d57acb2f6f70dd12906fe89743071be


Algorithm: Sha1
File: 1K.bin
Size: 1024 bytes
Iterations: 10
HW Accel: Kernel

a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
a29f7a414d57acb2f6f70dd12906fe89743071be
Elapsed: 0.005994 s | Throughput: 1.67 MiB/s


Algorithm: Sha256
File: 1K.bin
Size: 1024 bytes
Iterations: 10
HW accel: enabled

Elapsed: 0.000431 s | Throughput: 22.64 MiB/s
Final digest (last iteration): 71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8


Algorithm: Sha256
File: 1K.bin
Size: 1024 bytes
Iterations: 10
HW accel: disabled

Elapsed: 0.001099 s | Throughput: 8.88 MiB/s
Final digest (last iteration): 71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8


Algorithm: Sha256
File: 1K.bin
Size: 1024 bytes
Iterations: 10
HW Accel: Kernel

71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
71de956b691828855578522a482c84b46411eb7cbdfb55e37166698d1790d4e8
Elapsed: 0.005953 s | Throughput: 1.68 MiB/s


Algorithm: Sha1
File: 8K.bin
Size: 8192 bytes
Iterations: 10
HW accel: enabled

Elapsed: 0.000139 s | Throughput: 563.70 MiB/s
Final digest (last iteration): 96714a20bbb5d588ebe660591177a19b97960eea


Algorithm: Sha1
File: 8K.bin
Size: 8192 bytes
Iterations: 10
HW accel: disabled

Elapsed: 0.005767 s | Throughput: 13.55 MiB/s
Final digest (last iteration): 96714a20bbb5d588ebe660591177a19b97960eea


Algorithm: Sha1
File: 8K.bin
Size: 8192 bytes
Iterations: 10
HW Accel: Kernel

96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
96714a20bbb5d588ebe660591177a19b97960eea
Elapsed: 0.005649 s | Throughput: 14.16 MiB/s


Algorithm: Sha256
File: 8K.bin
Size: 8192 bytes
Iterations: 10
HW accel: enabled

Elapsed: 0.002570 s | Throughput: 30.39 MiB/s
Final digest (last iteration): cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085


Algorithm: Sha256
File: 8K.bin
Size: 8192 bytes
Iterations: 10
HW accel: disabled

Elapsed: 0.007709 s | Throughput: 10.13 MiB/s
Final digest (last iteration): cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085


Algorithm: Sha256
File: 8K.bin
Size: 8192 bytes
Iterations: 10
HW Accel: Kernel

cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
cf306145469a2321571dfe8738d3b8d5183e0bc49f641ceb43e3051710c9e085
Elapsed: 0.005643 s | Throughput: 14.18 MiB/s


Algorithm: Sha1
File: 64K.bin
Size: 65536 bytes
Iterations: 10
HW accel: enabled

Elapsed: 0.000562 s | Throughput: 1112.07 MiB/s
Final digest (last iteration): 6856c1927ca798b98aca2d19f1ba91422294db61


Algorithm: Sha1
File: 64K.bin
Size: 65536 bytes
Iterations: 10
HW accel: disabled

Elapsed: 0.045194 s | Throughput: 13.83 MiB/s
Final digest (last iteration): 6856c1927ca798b98aca2d19f1ba91422294db61


Algorithm: Sha1
File: 64K.bin
Size: 65536 bytes
Iterations: 10
HW Accel: Kernel

6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
6856c1927ca798b98aca2d19f1ba91422294db61
Elapsed: 0.006454 s | Throughput: 96.06 MiB/s


Algorithm: Sha256
File: 64K.bin
Size: 65536 bytes
Iterations: 10
HW accel: enabled

Elapsed: 0.019389 s | Throughput: 32.23 MiB/s
Final digest (last iteration): 82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8


Algorithm: Sha256
File: 64K.bin
Size: 65536 bytes
Iterations: 10
HW accel: disabled

Elapsed: 0.059996 s | Throughput: 10.42 MiB/s
Final digest (last iteration): 82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8


Algorithm: Sha256
File: 64K.bin
Size: 65536 bytes
Iterations: 10
HW Accel: Kernel

82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
82a37b366bc52c9d773c44432c4f7e2ade1d0510259401279d49e443eaad13c8
Elapsed: 0.006472 s | Throughput: 95.80 MiB/s


Algorithm: Sha1
File: 1M.bin
Size: 1048576 bytes
Iterations: 10
HW accel: enabled

Elapsed: 0.007631 s | Throughput: 1310.46 MiB/s
Final digest (last iteration): 3d924837bfa8692ddf6533e77af394370593501c


Algorithm: Sha1
File: 1M.bin
Size: 1048576 bytes
Iterations: 10
HW accel: disabled

Elapsed: 0.717626 s | Throughput: 13.93 MiB/s
Final digest (last iteration): 3d924837bfa8692ddf6533e77af394370593501c


Algorithm: Sha1
File: 1M.bin
Size: 1048576 bytes
Iterations: 10
HW Accel: Kernel

3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
3d924837bfa8692ddf6533e77af394370593501c
Elapsed: 0.014368 s | Throughput: 695.99 MiB/s


Algorithm: Sha256
File: 1M.bin
Size: 1048576 bytes
Iterations: 10
HW accel: enabled

Elapsed: 0.311672 s | Throughput: 32.08 MiB/s
Final digest (last iteration): dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5


Algorithm: Sha256
File: 1M.bin
Size: 1048576 bytes
Iterations: 10
HW accel: disabled

Elapsed: 0.959980 s | Throughput: 10.42 MiB/s
Final digest (last iteration): dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5


Algorithm: Sha256
File: 1M.bin
Size: 1048576 bytes
Iterations: 10
HW Accel: Kernel

dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
dae58405e0eacc3448ce24fdacf124c1b38add153fd8076971b8a96d6ca28ce5
Elapsed: 0.014027 s | Throughput: 712.91 MiB/s


```

### Contribution Statement ###

Responsibilities for Jack:

* Write rust implementation of hashing algorithms
* Prepare experiments to benchmark implementations
* Record demonstration
* Write script files for simple and easy replication of results

Responsibilities for Josh:

* Compile raw data
* Generate plots
* Write a clear README.md file
* Write report

Both Jack and Josh faithfully carried out the responsibilities assigned to them in order to satisfy the requirements of the assignment. No issues or discrepancies occurred concerning team member participation. 

Signed: 

Joshua Deckman (75a5e2946676fc44abceab49bc53c87bde5b1e837841501a3d7e7fec9eb2f09d)

Jack Pearson (8b7db6f1b39bb3be031bf06746922e3748e3c0ded57354b4185fe1ccf1b8bc84)
