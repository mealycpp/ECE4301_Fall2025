#!/usr/bin/env bash

# Usage & minimal validation
usage(){ echo "Usage: $(basename "$0") <filename> <iterations> <algorithm: sha1|sha256>"; exit 1; }
[[ $# -ne 3 ]] && usage
filename="$1"; iterations="$2"; algorithm=$(tr '[:upper:]' '[:lower:]' <<< "$3")
[[ "$algorithm" =~ ^(sha1|sha256)$ ]] || usage

# Header
alg_pretty="${algorithm^}"                      # sha1 -> Sha1
file_display="$(basename "$filename")"
size_bytes=$(stat -c%s "$filename")
echo "Algorithm: $alg_pretty"
echo "File: $file_display"
echo "Size: $size_bytes bytes"
echo "Iterations: $iterations"
echo "HW Accel: Kernel"
echo

# Time the hashing loop
start_ns=$(date +%s%N)
for ((i=1; i<=iterations; i++)); do
  kcapi-dgst --hex -c "$algorithm" -i "$filename"
  echo
done
end_ns=$(date +%s%N)

# Metrics
elapsed_ns=$((end_ns - start_ns))
elapsed_s=$(awk -v ns="$elapsed_ns" 'BEGIN{printf "%.6f", ns/1e9}')
total_mib=$(awk -v b="$size_bytes" -v n="$iterations" 'BEGIN{printf "%.2f", (b*n)/1024/1024}')
throughput=$(awk -v mib="$total_mib" -v s="$elapsed_s" 'BEGIN{printf "%.2f", (s>0)?(mib/s):0}')

echo "Elapsed: $elapsed_s s | Throughput: $throughput MiB/s"

