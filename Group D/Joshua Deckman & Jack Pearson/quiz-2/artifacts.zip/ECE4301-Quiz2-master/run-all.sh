#!/usr/bin/env bash
usage(){ echo "Usage: $(basename "$0") <filename> <iterations> <algorithm: sha1|sha256>"; exit 1; }

[[ $# -ne 3 ]] && usage
filename="$1"; iterations="$2"; algorithm=$(tr '[:upper:]' '[:lower:]' <<< "$3")
[[ "$algorithm" =~ ^(sha1|sha256)$ ]] || usage

cargo run --features hw-accel -- "$1" --iterations "$2" --algorithm "$3" --print-digest

echo
echo

cargo run -- "$1" --iterations "$2" --algorithm "$3" --print-digest

echo
echo

./kcapi-hash.sh "$1" "$2" "$3"

echo
echo
