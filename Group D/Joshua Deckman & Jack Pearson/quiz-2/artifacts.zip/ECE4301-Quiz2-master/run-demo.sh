#!/usr/bin/env bash

cam --camera=1 --capture=5 --file

for frame in frame-*; do
  xdg-open "$frame"
  cargo run --features hw-accel -- "$frame" --algorithm sha1 --print-digest
  cargo run --features hw-accel -- "$frame" --algorithm sha256 --print-digest
  cargo run -- "$frame" --algorithm sha1 --print-digest
  cargo run -- "$frame" --algorithm sha256 --print-digest
  echo "Press enter to continue"
  read
done
