#!/usr/bin/env bash

head -c $((1<<10)) /dev/urandom >1K.bin
head -c $((1<<13)) /dev/urandom >8K.bin
head -c $((1<<16)) /dev/urandom >64K.bin
head -c $((1<<20)) /dev/urandom >1M.bin

for f in 1K.bin 8K.bin 64K.bin 1M.bin; do
  ./run-all.sh $f 10 sha1
  ./run-all.sh $f 10 sha256
done

