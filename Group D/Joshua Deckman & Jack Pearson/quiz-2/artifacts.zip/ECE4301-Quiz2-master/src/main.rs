use std::fs;
use std::path::PathBuf;
use std::time::Instant;

use clap::{Parser, ValueEnum};
use sha2::Digest; // Re-export of the `digest` trait (works for both sha1 and sha2 types)

#[derive(Copy, Clone, Debug, ValueEnum)]
enum Algorithm {
    Sha1,
    Sha256,
}

#[derive(Parser, Debug)]
#[command(
    name = "rehash",
    about = "Repeatedly hash a file using SHA-1 or SHA-256 and report timing."
)]
struct Args {
    /// Path to the input file
    #[arg(value_name = "FILE")]
    file: PathBuf,

    /// Hash algorithm to use: sha1 or sha256
    #[arg(short = 'a', long = "algorithm", value_enum, default_value_t = Algorithm::Sha256)]
    algorithm: Algorithm,

    /// Number of times to hash the file (must be >= 1)
    #[arg(short = 'i', long = "iterations", value_parser = clap::value_parser!(usize), default_value_t = 1)]
    iterations: usize,

    /// Also print the final digest (hex) from the last iteration
    #[arg(long = "print-digest", default_value_t = false)]
    print_digest: bool,
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = Args::parse();

    // Validate iterations at runtime because the `.range()` helper isn't available
    // on the ValueParser in this toolchain. Ensure it's at least 1.
    if args.iterations == 0 {
        return Err("iterations must be >= 1".into());
    }

    // Load file once so we measure hashing, not disk I/O.
    let data = fs::read(&args.file)?;
    let data_len = data.len();

    println!(
        "Algorithm: {:?}\nFile: {}\nSize: {} bytes\nIterations: {}\nHW accel: {}\n",
        args.algorithm,
        args.file.display(),
        data_len,
        args.iterations,
        if cfg!(feature = "hw-accel") { "enabled" } else { "disabled" }
    );

    // Time only the hashing loop.
    let start = Instant::now();

    // Keep the last digest to prevent the compiler from optimizing the loop away.
    let mut last_hex = String::new();

    match args.algorithm {
        Algorithm::Sha1 => {
            use sha1::Sha1;
            for _ in 0..args.iterations {
                let mut hasher = Sha1::new();
                hasher.update(&data);
                let digest = hasher.finalize(); // Output<sha1::Sha1>
                if args.print_digest {
                    // This formatting implements LowerHex for digest outputs.
                    last_hex.clear();
                    last_hex = format!("{:x}", digest);
                }
            }
        }
        Algorithm::Sha256 => {
            use sha2::Sha256;
            for _ in 0..args.iterations {
                let mut hasher = Sha256::new();
                hasher.update(&data);
                let digest = hasher.finalize();
                if args.print_digest {
                    last_hex.clear();
                    last_hex = format!("{:x}", digest);
                }
            }
        }
    }

    let elapsed = start.elapsed();
    let secs = elapsed.as_secs_f64();

    // Basic throughput: total bytes hashed / elapsed time.
    let total_hashed = (data_len as f64) * (args.iterations as f64);
    let mib_per_sec = if secs > 0.0 {
        (total_hashed / (1024.0 * 1024.0)) / secs
    } else {
        f64::INFINITY
    };

    println!(
        "Elapsed: {:.6} s | Throughput: {:.2} MiB/s",
        secs, mib_per_sec
    );

    if args.print_digest {
        println!("Final digest (last iteration): {}", last_hex);
    }

    Ok(())
}
