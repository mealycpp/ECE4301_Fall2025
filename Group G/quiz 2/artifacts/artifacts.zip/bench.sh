#!/usr/bin/env bash
set -euo pipefail

BIN="${1:-accel}"      # accel or soft
ALGO="${2:-sha256}"    # sha1 or sha256
CORE="${3:-3}"

SIZES="1024,8192,65536,1048576"
OUTDIR="out"

mkdir -p "$OUTDIR"

# Your binaries live in ./target/release, not rpi-hash-cli/target
EXE="./target/release/$BIN"

if [[ ! -x "$EXE" ]]; then
  echo "Build first: ./scripts/build.sh $BIN"
  exit 1
fi

CSV="$OUTDIR/${ALGO}_${BIN}.csv"

echo "# Running $BIN $ALGO ..."

taskset -c "$CORE" "$EXE" \
  --algo "$ALGO" \
  --pin-core "$CORE" \
  --csv "$CSV" \
  bench --sizes "$SIZES" --trials 5 \
  | tee "$OUTDIR/${ALGO}_${BIN}.log"

echo "Wrote $CSV"
