#!/usr/bin/env bash
set -euo pipefail

BIN="${1:-}"

if [[ "$BIN" != "soft" && "$BIN" != "accel" ]]; then
  echo "Usage: scripts/build.sh [soft|accel]"
  exit 1
fi

# Run from the workspace root (~/quiz-2)
pushd sha-cli > /dev/null

if [[ "$BIN" == "soft" ]]; then
  # Only disable sha2 to avoid huge -sha1 warnings
  RUSTFLAGS='-C target-feature=-sha2' \
    cargo build --release --bin soft --features soft
else
  cargo build --release --bin accel --features accel
fi

popd > /dev/null

echo "Built target/release/$BIN"
