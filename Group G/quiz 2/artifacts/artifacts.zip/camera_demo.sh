#!/usr/bin/env bash
set -euo pipefail

OUTDIR="demo_imgs"
mkdir -p "$OUTDIR"

# Take 5 still images with the Pi camera
for i in 1 2 3 4 5; do
  rpicam-still -o "$OUTDIR/img_$i.jpg" -t 10 --width 1920 --height 1080
done

EXESOFT="./target/release/soft"
EXEACC="./target/release/accel"

if [[ ! -x "$EXESOFT" || ! -x "$EXEACC" ]]; then
  echo "Build both first: ./scripts/build.sh soft && ./scripts/build.sh accel"
  exit 1
fi

echo "=== soft ==="
"$EXESOFT" --algo sha1   files "$OUTDIR"
"$EXESOFT" --algo sha256 files "$OUTDIR"

echo "=== accel ==="
"$EXEACC" --algo sha1    files "$OUTDIR"
"$EXEACC" --algo sha256  files "$OUTDIR"
