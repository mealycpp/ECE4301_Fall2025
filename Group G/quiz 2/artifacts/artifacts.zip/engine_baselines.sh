#!/usr/bin/env bash
set -euo pipefail

OUTDIR="out"
mkdir -p "$OUTDIR"

# Kernel crypto API benchmarks (if available)
if command -v kcapi-speed >/dev/null 2>&1; then
  for ALG in sha1 sha256 sha1-ce sha256-ce sha1-generic sha256-generic; do
    echo "=== kcapi-speed $ALG ===" | tee -a "$OUTDIR/kcapi-speed.log"
    for SZ in 1024 8192 65536 1048576; do
      kcapi-speed -t hash -a "$ALG" -s "$SZ" -n 5 2>&1 | tee -a "$OUTDIR/kcapi-speed.log"
    done
  done
else
  echo "kcapi-speed not found; skipping" | tee -a "$OUTDIR/kcapi-speed.log"
fi

# OpenSSL engine baselines
if command -v openssl >/dev/null 2>&1; then
  for ALG in sha1 sha256; do
    for SZ in 1024 8192 65536 1048576; do
      echo "=== openssl speed -evp $ALG, $SZ bytes ===" | tee -a "$OUTDIR/openssl-speed.log"
      taskset -c 3 openssl speed -elapsed -evp "$ALG" -bytes "$SZ" 2>&1 | tee -a "$OUTDIR/openssl-speed.log"
    done
  done
else
  echo "openssl not found; skipping" | tee -a "$OUTDIR/openssl-speed.log"
fi
