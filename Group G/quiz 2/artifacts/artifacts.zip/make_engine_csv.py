#!/usr/bin/env python3
import re, csv
from pathlib import Path

OUT = Path("out")
SIZES = [1024, 8192, 65536, 1048576]

def parse_openssl(log_path: Path, algo_name: str):
    """Return list of MB/s in the order of SIZES."""
    mbps = []
    with log_path.open() as f:
        for line in f:
            line = line.strip()
            # lines look like: "sha1           1054214.14k"
            if line.startswith(algo_name):
                parts = line.split()
                val_k = float(parts[-1].rstrip("k"))
                # k = 1000 bytes/s, convert to MiB/s
                mbps.append(val_k / 1024.0)
    assert len(mbps) == len(SIZES), f"Expected {len(SIZES)} entries, got {len(mbps)}"
    return mbps

def write_csv(csv_path: Path, algo_label: str, sizes, mbps):
    with csv_path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["algo", "size_bytes", "mb_per_s_mean"])
        for s, m in zip(sizes, mbps):
            w.writerow([algo_label, s, m])

if __name__ == "__main__":
    sha1_vals = parse_openssl(OUT / "openssl_sha1.log", "sha1")
    sha2_vals = parse_openssl(OUT / "openssl_sha256.log", "sha256")

    write_csv(OUT / "sha1_engine.csv", "Engine", SIZES, sha1_vals)
    write_csv(OUT / "sha256_engine.csv", "Engine", SIZES, sha2_vals)

    print("Wrote out/sha1_engine.csv and out/sha256_engine.csv")
