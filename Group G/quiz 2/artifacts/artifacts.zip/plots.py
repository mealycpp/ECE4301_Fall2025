#!/usr/bin/env python3

import csv, sys
import matplotlib.pyplot as plt
from pathlib import Path

def load(csv_path):
    xs, ys = [], []
    with open(csv_path) as f:
        rdr = csv.DictReader(f)
        for row in rdr:
            xs.append(int(row["size_bytes"]))
            ys.append(float(row["mb_per_s_mean"]))
    return xs, ys

def plot_three(title, x1,y1, l1, x2,y2, l2, x3,y3, l3, out):
    plt.figure()
    plt.title(title)
    plt.xlabel("Message size (bytes)")
    plt.ylabel("Throughput (MB/s)")
    plt.xscale("log", base=2)
    plt.plot(x1,y1, marker='o', label=l1)
    plt.plot(x2,y2, marker='o', label=l2)
    plt.plot(x3,y3, marker='o', label=l3)
    plt.legend()
    plt.grid(True, which="both", ls=":")
    plt.tight_layout()
    plt.savefig(out, dpi=200)

if __name__ == "__main__":
    sha1_soft = "out/sha1_soft.csv"
    sha1_acc  = "out/sha1_accel.csv"
    sha1_eng  = "out/sha1_engine.csv"

    sha2_soft = "out/sha256_soft.csv"
    sha2_acc  = "out/sha256_accel.csv"
    sha2_eng  = "out/sha256_engine.csv"

    x1,y1 = load(sha1_soft); x2,y2 = load(sha1_acc); x3,y3 = load(sha1_eng)
    plot_three("SHA-1 throughput vs size", x1,y1,"Rust-soft", x2,y2,"Rust-accel", x3,y3,"Engine", "out/sha1_plot.png")

    x1,y1 = load(sha2_soft); x2,y2 = load(sha2_acc); x3,y3 = load(sha2_eng)
    plot_three("SHA-256 throughput vs size", x1,y1,"Rust-soft", x2,y2,"Rust-accel", x3,y3,"Engine", "out/sha256_plot.png")

    print("Wrote out/sha1_plot.png and out/sha256_plot.png")
