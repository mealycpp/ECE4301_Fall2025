use anyhow::{bail, Result};
use clap::{Parser, Subcommand, ValueEnum};
use rand::{rngs::StdRng, RngCore, SeedableRng};
use std::fs::File;
use std::io::Read;
use std::path::PathBuf;
use std::time::{Duration, Instant};
use walkdir::WalkDir;
use digest::Digest;

#[derive(Copy, Clone, Debug, ValueEnum)]
enum Algo {
    Sha1,
    Sha256,
}

#[derive(Parser, Debug)]
#[command(name="sha-cli", version, about="SHA-1/SHA-256 bench + file hashing")]
struct Cli {
    #[arg(long, value_enum, default_value="sha256")]
    algo: Algo,

    #[arg(long)]
    pin_core: Option<usize>,

    #[arg(long)]
    csv: Option<PathBuf>,

    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand, Debug)]
enum Cmd {
    Bench {
        #[arg(long, default_value="1024,8192,65536,1048576")]
        sizes: String,

        #[arg(long, default_value_t = 5)]
        trials: usize,
    },

    Files {
        paths: Vec<PathBuf>,
    },
}

fn pin_to_core(core: usize) -> Result<()> {
    #[cfg(target_os = "linux")]
    {
        use libc::{cpu_set_t, sched_setaffinity, CPU_SET, CPU_ZERO};
        unsafe {
            let mut set: cpu_set_t = std::mem::zeroed();
            CPU_ZERO(&mut set);
            CPU_SET(core, &mut set);
            let pid = 0;
            let res = sched_setaffinity(pid, std::mem::size_of::<cpu_set_t>(), &set);
            if res != 0 {
                eprintln!("Warning: sched_setaffinity failed");
            }
        }
    }
    Ok(())
}

fn digest_once(algo: Algo, buf: &[u8]) -> Vec<u8> {
    match algo {
        Algo::Sha1 => {
            let mut h = sha1::Sha1::new();
            h.update(buf);
            h.finalize().to_vec()
        }
        Algo::Sha256 => {
            let mut h = sha2::Sha256::new();
            h.update(buf);
            h.finalize().to_vec()
        }
    }
}

fn bench_once(algo: Algo, size: usize) -> (Duration, f64) {
    let mut rng = StdRng::seed_from_u64(0xBAD5EED);
    let mut buf = vec![0u8; size];
    rng.fill_bytes(&mut buf);

    let iters = if size < 64 * 1024 {
        10_000usize.max(1_000_000 / size)
    } else {
        256
    };

    let start = Instant::now();
    let mut acc = 0u8;

    for _ in 0..iters {
        let out = digest_once(algo, &buf);
        acc ^= out[0];
    }

    let dur = start.elapsed();
    let bytes = (size as u128) * (iters as u128);
    let mbps = (bytes as f64) / (1024.0 * 1024.0) / dur.as_secs_f64();

    std::hint::black_box(acc);
    (dur, mbps)
}

fn parse_sizes(s: &str) -> Result<Vec<usize>> {
    let mut v = Vec::new();
    for tok in s.split(',') {
        let trimmed = tok.trim();
        if trimmed.is_empty() { continue; }
        let sz: usize = trimmed.parse().map_err(|_| anyhow::anyhow!("Bad size: {trimmed}"))?;
        v.push(sz);
    }
    if v.is_empty() { bail!("No sizes parsed"); }
    Ok(v)
}

fn main() -> Result<()> {
    let cli = Cli::parse();

    if let Some(core) = cli.pin_core {
        let _ = pin_to_core(core);
    }

    match cli.cmd {
        Cmd::Bench { sizes, trials } => {
            let sizes = parse_sizes(&sizes)?;
            let mut rows: Vec<(usize, f64)> = Vec::new();

            println!("# algo={:?}", cli.algo);
            println!("{:<12} {:>12} {:>12}", "size(bytes)", "MB/s(mean)", "MB/s(stdev)");

            for sz in sizes {
                let mut vals = Vec::with_capacity(trials);
                for _ in 0..trials {
                    let (_d, mbps) = bench_once(cli.algo, sz);
                    vals.push(mbps);
                }

                let mean = vals.iter().copied().sum::<f64>() / (vals.len() as f64);
                let var = vals
                    .iter()
                    .map(|v| (v - mean) * (v - mean))
                    .sum::<f64>()
                    / (vals.len().max(2) as f64 - 1.0);
                let stdev = var.sqrt();

                println!("{:<12} {:>12.2} {:>12.2}", sz, mean, stdev);
                rows.push((sz, mean));
            }

            if let Some(csv) = cli.csv {
                let mut w = std::fs::File::create(&csv)?;
                use std::io::Write;
                writeln!(w, "algo,size_bytes,mb_per_s_mean")?;
                for (sz, mean) in rows {
                    writeln!(w, "{:?},{},{}", cli.algo, sz, mean)?;
                }
                eprintln!("wrote {}", csv.display());
            }
        }

        Cmd::Files { paths } => {
            if paths.is_empty() {
                bail!("Provide at least one file or directory");
            }

            for p in paths {
                if p.is_dir() {
                    for entry in WalkDir::new(&p).into_iter().filter_map(|e| e.ok()) {
                        let f = entry.path();
                        if f.is_file() {
                            hash_file(cli.algo, f)?;
                        }
                    }
                } else {
                    hash_file(cli.algo, &p)?;
                }
            }
        }
    }

    Ok(())
}

fn hash_file(algo: Algo, path: &std::path::Path) -> Result<()> {
    let mut file = File::open(path)?;
    let mut buf = Vec::new();
    file.read_to_end(&mut buf)?;

    let start = Instant::now();
    let out = digest_once(algo, &buf);
    let dur = start.elapsed();

    println!(
        "{}  {}  {} ms",
        match algo { Algo::Sha1 => "SHA1", Algo::Sha256 => "SHA256" },
        hex::encode(out),
        (dur.as_secs_f64() * 1000.0).round()
    );

    Ok(())
}
